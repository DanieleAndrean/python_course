ItList=[    {"name":"Pokeball",
             "maxNum":10
            },
            
            {"name":"Health Potion",
             "maxNum":10
             }
]