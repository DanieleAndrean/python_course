import copy
import numpy as np
import UserInput
import random
import math
import os
from PokeData.load import TypEffList
class baseStats:
    def __init__(self,bsDict):
        self.hp=bsDict["hp"]
        self.attack=bsDict["attack"]
        self.defense=bsDict["defense"]
        self.speed=bsDict["speed"]
        self.special=bsDict["special"]

    def update(self,hp,attack,defense,speed,special):
        self.hp=hp
        self.attack=attack
        self.defense=defense
        self.speed=speed
        self.special=special

    def getMaxHP(self):
        return copy.deepcopy(self.hp)

#################################################
############### MOVE CLASS ###################
#################################################

class Move:
    def __init__(self,moveDict):
        self.name=moveDict["name"]
        self.type=moveDict["type"]
        self.category=moveDict["category"]
        self.power=moveDict["power"]
        self.accuracy=moveDict["accuracy"]
        self.maxPP=moveDict["pp"]
        self.pp=self.maxPP

    def decPP(self):
        self.pp-=1

    def restorePP(self,*numPP):
        #if numPP is not empty
        if numPP:
            self.pp+=numPP[0]
            if self.pp>self.maxPP:
                self.pp=self.maxPP
        else:
            self.pp=self.maxPP
        
    def getPP(self):
        return copy.deepcopy(self.pp)
    
    def __str__(self):
        movestr=self.name+"  type:"+self.type+"  power:"+str(self.power)+"\n"
        return movestr
    

#################################################
############### POKEMON CLASS ###################
#################################################
class Pokemon:
    def __init__(self,PokeDict,moves):
        self.Level=1
        self.Name=PokeDict["name"]
        self.MaxMoves=4
        self.Types=PokeDict["types"]
        self.baseStats=baseStats(PokeDict["baseStats"])
        self.moves=[]
        for i in range(len(moves)):
            self.moves.append(Move(moves[i]))
        self.currentHP=self.baseStats.hp
        self.Pokedex=PokeDict["national_pokedex_number"]
        self.KO=False

    def __str__(self):
        typ=""
        for i in range(len(self.Types)):
            typ=typ+self.Types[i]+" "
        Pokestr=self.Name+"\t lv: "+str(self.Level)+"\t  type: "+typ+"\n"
        return Pokestr
    
    #tells if Pokemon is KO
    def isKO(self):
        return copy.deepcopy(self.KO)
    
    #returns a copy of the current HP
    def showHP(self):
        return copy.deepcopy(self.currentHP)    
    
    #returns a string to display the current moves
    def movesDisp(self,*sel):
        if len(sel)==0: #display all
            mvDisp=""
            for i in range(len(self.moves)):
                mvDisp=mvDisp+str(i)+": "+str(self.moves[i])+"  PP: "+str(self.moves[i].getPP())+"\n"
            
            return mvDisp
        else: #display selected
            idxs=sel[0]
            mvDisp=""
            for i in range(len(idxs)):
                    mvDisp=mvDisp+str(idxs[i])+": "+str(self.moves[idxs[i]])+"  PP: "+str(self.moves[idxs[i]].getPP())+"\n"
            if mvDisp=="":
                raise Exception("No available moves")
            return mvDisp
    

    #returns a list of indexes with available moves only
    def availMoves(self):
        idxs=[]
        for i in range(len(self.moves)):
            if(self.moves[i].getPP()>0):
                idxs.append(i)
        return idxs


    #adds a move to current move list, if the Pokemon already knows 4 moves, the user is asked to choose which one to forget
    def addMove(self,mv):
        
        self.moves.append(Move(mv))
        #max number of moves check
        if len(self.moves)>self.MaxMoves:
            #request user which move to drop
            UserInput.askInput("",self.Name+" is trying to learn a new move but it must forget one.\n Press Enter to continue")
            os.system("cls")
            errmsg=["You must provide a number","You must choose a value among the specified ones"]
            msg="choose a move to forget:\n"+self.movesDisp()
            drop=UserInput.inputLoop("int",msg,errmsg,[0,1,2,3,4])
            self.dropMove(drop)
    
    #removes the move in position "drop" from moves list 
    def dropMove(self,drop):
        self.moves.pop(drop)


    #decrease current HP by the specified amount
    def decHP(self,HPloss):
      
        self.currentHP-=HPloss
        if self.currentHP<=0:
            self.currentHP=0
            self.KO=True

    def heal(self,*quantity):
        #if quantity is not empty
        if quantity:
            self.currentHP+=quantity[0]
            if self.currentHP>self.baseStats.hp:
                self.currentHP=self.baseStats.hp
        else:
            self.currentHP=self.baseStats.hp
            self.KO=False
            

    #uses the selected move and resolves it effects
    def useMove(self,mv,target):
        selMove=self.moves[mv]
        selMove.decPP()

        succProb=random.random()
        #dmg computation
        if selMove.accuracy>succProb:
            if selMove.category=="physical":
                atk=self.baseStats.attack
                dfn=target.baseStats.defense
            else:
                atk=self.baseStats.special
                dfn=target.baseStats.special

            #stability modifier calculation
            if selMove.type in self.Types:
                stability=1.5
            else:
                stability=1
        
            effect=np.prod([eff["effectiveness"] for eff in TypEffList 
                            if eff["attack"]==selMove.type and eff["defend"] in target.Types])
            #critical modifier calculation
            if random.random()<self.baseStats.speed/512:
                critical=2
            else:
                critical=1
            
            luck=0.85+(0.15)*random.random()
            modif=stability*effect*critical*luck
            dmg=math.floor((((2*self.Level+10)/250)*(atk/dfn)*selMove.power+2)*modif)
            #apply damage
            target.decHP(dmg)

            return True #attack succeded
        
        else:
            return False #attack missed




