aniele Andrean PhD student @DEI 
supervisor: prof. Morten Gram Pedersen

Run the main.py file to generate the results and save them.

Run the Visualize.py file to load and visualize the results.

Simulation results are already provided to avoid the recalculation.

The first pot shows the number of victories for each Pokemon over 150 battles for each of the 500 simulations. Means over the simulation
are reported as dashed lines.

The second plot reports the Boxplots with the number of turn and the percentage of remaining HP at the end of each combat. 
Due to the high number of lost matches, the HP boxplot is squeezed around 0.

The last 3 plots report the encountered pokemons-specific statistics. Each starter Pokemon has it own graph.
Only the Pokemons which are marked as "easy" or "hard" to beat are shown in the third plot as showing all the enconuntered 
Pokemons resulted in messy plots.
 